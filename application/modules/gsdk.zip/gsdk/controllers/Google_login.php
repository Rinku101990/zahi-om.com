<?php defined('BASEPATH') OR exit('No direct script access allowed');

class Google_login extends MY_Controller {
    function __construct() {
        parent::__construct();
        // Load user model
        $this->load->model('user');
    }
    
    public function index(){
        // Load login & profile view
        $this->load->view('google_login/index');
    }

    public function saveUserData() {
        // Decode json data and get user profile data
        $postData = json_decode($_POST['profile']);

        print_r($postData);die;
        
        // Preparing data for database insertion
        // $userData['oauth_provider'] = $_POST['oauth_provider'];
        // $userData['oauth_uid']         = $postData->id;
        // $userData['first_name']     = $postData->first_name;
        // $userData['last_name']         = $postData->last_name;
        // $userData['email']             = $postData->email;
        // $userData['gender']         = $postData->gender;
        // $userData['locale']         = $postData->locale;
        // $userData['cover']             = $postData->cover->source;
        // $userData['picture']         = $postData->picture->data->url;
        // $userData['link']             = $postData->link;
        
        // // Insert or update user data
        // $userID = $this->user->checkUser($userData);
        
        // return true;
    }
}