<!DOCTYPE html>
<html lang="en">
<head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <title>Login with Google Accont using JavaScript OAuth Library  &ndash; Coding Birds Online</title>

    <script src="https://apis.google.com/js/platform.js?onload=renderButton" async defer></script>
    <meta name="google-signin-client_id" content="381135714235-3ietvvglsp57up52nf1kv53fl2spvlr0.apps.googleusercontent.com">


</head>
<body>
<center><h5 >Login with Google using JavaScript OAuth Library</h5></center>
<center><div id="g-signin2"></div></center>
<!-- End post-content Area -->
<script>
    function renderButton() {
        gapi.signin2.render('g-signin2', {
            'scope': 'profile email',
            'width': 250,
            'height': 40,
            'longtitle': true,
            'theme': 'dark',
            'onsuccess': onSignIn,
            'onfailure': onFailure
        });
    }

    function onSignIn(googleUser) {

        var profile = googleUser.getBasicProfile();

        // console.log('ID: ' + profile.getId()); // Do not send to your backend! Use an ID token instead.
        // console.log('Name: ' + profile.getName());
        // console.log('Image URL: ' + profile.getImageUrl());
        // console.log('Email: ' + profile.getEmail());

        // var googleTockenId = profile.getId();
        // var name = profile.getName();
        // var email = profile.getEmail();
        // var profile = profile.getImageUrl();

        // $("#loaderIcon").show('fast');
        // $("#g-signin2").hide('fast');

        saveUserData(profile); // save data to our database for reference
    }

    // Sign-in failure callback
    function onFailure(error) {
        alert(error);
    }

    // Sign out the user
    function signOut() {
        if(confirm("Are you sure to signout?")){
            var auth2 = gapi.auth2.getAuthInstance();
            auth2.signOut().then(function () {
                $("#loginDetails").hide();
                $("#loaderIcon").hide('fast');
                $("#g-signin2").show('fast');
            });

            auth2.disconnect();
        }
    }

    function saveUserData(profile) {
        $.post("script.php",{authProvider:"Google",profile: JSON.stringify(profile)},
            function(data){ return true; });
    }
</script>
</body>
</html>
