<h2>CodeIgniter Google Login</h2>
<!-- Display sign in button -->
<a href="<?php echo $loginURL; ?>"><img src="<?php echo base_url('assets/images/google-sign-in-btn.png'); ?>" /></a>