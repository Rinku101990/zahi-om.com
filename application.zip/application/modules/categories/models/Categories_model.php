<?php 
class Categories_model extends MY_Model{

	
}