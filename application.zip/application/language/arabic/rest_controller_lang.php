<?php

	$lang['I\'m a man'] = "انا رجل";

?>