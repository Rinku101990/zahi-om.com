<?php

$config['facebook_app_id']              = '435038420980031';
$config['facebook_app_secret']          = '87d96c4107d1616eedb3a6e3bbe9356a';
$config['facebook_login_type']          = 'web';
$config['facebook_login_redirect_url']  = 'user_authentication';
$config['facebook_logout_redirect_url'] = 'user_authentication/logout';
$config['facebook_permissions']         = array('email');
$config['facebook_graph_version']       = 'v2.10';
$config['facebook_auth_on_load']        = TRUE;

?>