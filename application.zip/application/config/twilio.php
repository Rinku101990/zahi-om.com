<?php 
 
if ( ! defined('BASEPATH')) exit('No direct script access allowed');
 
$config['mode'] = 'sandbox';
 
/**
* Account SID
**/
//$config['account_sid'] = 'Your account sid that are acess from twilio dashboard';
$config['account_sid'] = 'AC3ba517fdd8bd5bd9d14d4743b5ce27c6';
 
/**
* Auth Token
**/
//$config['auth_token'] = 'Your Authentication acess from twilio dashboard';
$config['auth_token'] = '706a0047d4ffd153e1cec3cc7822baa5';
 
/**
* API Version
**/
$config['api_version'] = '2010-04-01';
 
/**
* Twilio Phone Number
**/
$config['number'] = '+447723561455';
 
/* End of file twilio.php */
?>