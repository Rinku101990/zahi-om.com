<?php 
 $this->load->view('include/header');
 $this->load->view('include/left-sidebar');
 $this->load->view($subview); 
  //$this->load->view('include/right-sidebar');
 $this->load->view('include/footer'); 
 ?>